// The IJKL scheme, as CodeMirror 6 bindings. One table per *mode*, and six
// modes.
//
// It used to be two tables — blog's eight motions and tracker's 47 — which
// disagreed about ctrl+j and ctrl+l: the markdown "sentence" motions in one, line
// start and end in the other. That was tracker's own invention and appears
// nowhere in the top-level README, whose only definition of those two chords is
// the markdown one. So they are the markdown motions now, and where the two sets
// disagreed the newer behaviour won.
//
// The tables here are not that argument coming back — that argument was about
// what a chord means in *one* kind of document. These are one layout on six
// kinds:
//
//   'markdown'  the default, and what every consumer had before modes existed: a
//               markdown document, with blocks to move between and Clojure
//               and JSON fences to move inside. 50 chords — the 48 every document has,
//               and the two leftward structural ones, which only a document
//               that can contain Clojure has anything to do with.
//   'text'      a text file. The 48; nine of them do something
//               simpler, because there are no blocks and no fences. ctrl+j and
//               ctrl+l are the ends of the *line* — and, pressed again from
//               there, the end of the line above and the start of the one below —
//               and the option four are the plain word and line motions that
//               markdown mode already falls back to everywhere outside a fence.
//   'source'    a source-code file that is not Lisp — .sh, .py, a Makefile, a
//               dot-rc file, an ignore file, .yaml, .toml, .js. Text mode plus
//               the indent stage on ctrl+j: to the indentation first, then the
//               line start, then the end of the line above. 'shell' is this
//               mode's first, narrower name — from when the only source files
//               the scheme had met were shell scripts — and still resolves
//               to it.
//   'clojure'   a Clojure source file — .clj, .cljs, .cljc, .edn. The same 49
//               chords as markdown; the same eight that markdown overrides are
//               overridden, and to the same things, because a .clj is what a
//               ```clojure block is a piece of — and the two structural chords
//               apply to the whole file rather than to a fence in it.
//   'json'      a .json or .jsonc. Clojure mode's table exactly, chord for
//               chord, on JSON's reader: a value is a form, an object or an
//               array is a list, and the colon is whitespace beside the comma,
//               so a key and its value are two forms as they are in a map.
//   'input'     one line, and only one — a title field, a search box. 32 chords.
//
// What a mode drops or changes, it drops or changes because *the document is not
// that shape*, never because a chord was reconsidered. There is no block in a
// text file, so there is nothing for a block motion to move between; there is no
// second line in a field, so there is nothing to move a line above or below.
//
// **Built in layers, so a chord is written once and every mode that has it gets
// the same one** — by identity, not by two tables that happen to agree today:
//
//   sharedBindings         any document at all. The char motions, deleting, the
//                          clipboard, undo, select-all. cmd+j means the same
//                          thing in a search box and in a thousand-line file.
//     multiLineBindings    ...once there is a second line: vertical motion, the
//                          line operations, paging, scrolling, centring. This
//                          *is* text mode, and the base the other two documents
//                          are written as differences from.
//       markdownBindings   ...+ blocks and fences: eight chords overridden. Three
//                          languages are understood inside a fence, and only
//                          three: Clojure and JSON, where the option four move by
//                          form, and shell-like, where the ctrl pair goes back to
//                          being the ends of the line.
//       sourceBindings     ...+ the indent stage on ctrl+j, and nothing else yet.
//       clojureBindings    ...+ the same eight markdown overrides, with the
//                          fence question already answered. Markdown asks *am I
//                          in a ```clojure block* and *am I in a shell-like
//                          one*; in a .clj the answers are always yes and always
//                          no, so the option four move by form over the whole
//                          file and the ctrl pair is the block motion — which in
//                          Clojure is the top-level form.
//       jsonBindings       ...+ the same, on JSON's reader rather than Clojure's.
//     inputBindings        ...when there is not: one line, and eight chords
//                          swallowed.
//
// Nothing here imports CodeMirror. The `@codemirror/commands` namespace is
// handed in instead, for one reason that matters in practice: a bundle with two
// copies of @codemirror/state in it breaks in ways that are very hard to read,
// and a library that imports its own copy is how you get there. The consumer
// already has CodeMirror — blog on `window.CM6.commands`, a shadow-cljs app on
// its own `["@codemirror/commands" :as commands]`. It passes that in.
//
// So this package has no dependencies. That is deliberate.

import {sentenceStart, sentenceEnd,
        lineStartOrPrevEnd, lineEndOrNextStart,
        indentOrLineStartOrPrevEnd} from './motions.js';
import {formsFenceAt, shellFenceAt} from './fences.js';
import {forwardSexp, backwardSexp, forwardDownSexp, forwardUpSexp,
        backwardUpSexp, backwardDownSexp, formStart, formEnd,
        clojureSyntax, jsonSyntax} from './sexp.js';
import {copySelection, pasteAtSelection, cutSelection,
        newLineBelow, newLineAbove,
        scrollDown, scrollUp, cursorViewportUp, cursorViewportDown,
        centerCaret, centerLine} from './custom-commands.js';

export const MARKDOWN = 'markdown';
export const TEXT = 'text';
export const SOURCE = 'source';
export const CLOJURE = 'clojure';
export const INPUT = 'input';

// 'json', under the one name here that cannot be the bare word: an export
// called JSON shadows the global in any module that imports it, and the first
// JSON.stringify after that is a TypeError a long way from its cause.
export const JSON_MODE = 'json';

// The name source mode went by when shell scripts were the only source files
// here — kept, and kept working, exactly as DOCUMENT is kept below: it is
// exported, so a consumer may be spelling it out (the coordinator panels say
// 'shell' today). It resolves to the source layout, which is what it always
// was: the spec's source category *contains* the shell script, so the mode
// widened rather than changed, and a caller that said 'shell' gets whatever
// source mode grows the day it grows it.
export const SHELL = 'shell';

// The name markdown mode went by when it was the only document mode there was,
// kept and kept working. It is exported, so a consumer may be spelling it out —
// and blog ships a *bundle* of this library that re-exports everything on
// `window.IJKL`, where an old page and a new bundle meet. `bindings` resolves it
// to the markdown layout, which is what it always was: markdown mode is not a
// new behaviour, it is the old one with a name that says which of four it is.
export const DOCUMENT = 'document';

// Keyed on e.code, never e.key: on macOS Option is a compose modifier, so
// option+j arrives as e.key "∆". An e.key map would fail silently for
// exactly the two wordwise bindings and look fine everywhere else.
export function chord(e) {
  const mods = [];
  if (e.altKey) mods.push('alt');
  if (e.ctrlKey) mods.push('ctrl');
  if (e.metaKey) mods.push('meta');
  if (e.shiftKey) mods.push('shift');
  return e.code + ' ' + mods.join('+');
}

// A pure motion as a CodeMirror command: the function decides where, this only
// moves the caret there.
export function motion(fn) {
  return function (view) {
    const target = fn(view.state.doc.toString(), view.state.selection.main.head);
    view.dispatch({selection: {anchor: target, head: target}, scrollIntoView: true});
    return true;
  };
}

// The same motion, selecting: the anchor stays where it was and only the head
// moves, which is what makes shift+chord mean "select as far as chord would go".
// Needed because ctrl+j and ctrl+l are not line start and end in markdown mode —
// their shifted pair had been CodeMirror's selectLineStart/End, and leaving those
// behind would have meant shift+ctrl+j selecting somewhere ctrl+j never goes.
export function selectTo(fn) {
  return function (view) {
    const selection = view.state.selection.main;
    const target = fn(view.state.doc.toString(), selection.head);
    view.dispatch({selection: {anchor: selection.anchor, head: target}, scrollIntoView: true});
    return true;
  };
}

// Removing the text between the caret and somewhere — the shape every kill in
// this scheme has. A selection is deleted as it stands, which is what any
// delete key does and what stops a kill from reaching past a selection the user
// made on purpose.
function removeBetween(view, a, b) {
  if (a === b) return true;
  const from = a < b ? a : b;
  const to = a < b ? b : a;
  view.dispatch({changes: {from, to, insert: ''},
                 selection: {anchor: from, head: from},
                 scrollIntoView: true});
  return true;
}

// A pure motion as a *deletion*: the function says how far the kill reaches and
// this removes what lies between there and the caret. The motion-shaped sibling
// of motion() and selectTo(), so a kill and the movement it mirrors cannot
// disagree about where a form ends — option+delete removes exactly what
// option+j would have moved over.
export function deleteTo(fn) {
  return function (view) {
    const sel = view.state.selection.main;
    if (sel.from !== sel.to) return removeBetween(view, sel.from, sel.to);
    return removeBetween(view, fn(view.state.doc.toString(), sel.head), sel.head);
  };
}

// The reader each kind of fence of forms is read with — see formsFenceAt.
const READERS = {clojure: clojureSyntax, json: jsonSyntax};

// The same, fence-aware: a kill by form inside a ```clojure or ```json block,
// and the fallback everywhere else. sexpAware() for deletions, and separate
// from it because what it does with the answer is a change rather than a
// selection.
export function sexpAwareDelete(kill, fallback) {
  return function (view) {
    const sel = view.state.selection.main;
    if (sel.from !== sel.to) return removeBetween(view, sel.from, sel.to);
    const text = view.state.doc.toString();
    const fence = formsFenceAt(text, sel.head);
    if (!fence) return fallback(view);
    return removeBetween(view, kill(text, sel.head, fence.from, fence.to, READERS[fence.reader]),
                         sel.head);
  };
}

// The same chord meaning one thing in prose and another inside a ```clojure
// block — which is what makes structural editing bindable on keys that are
// already spoken for. Outside such a block the fallback runs and nothing has
// changed; inside one, movement is by form and cannot leave the block.
//
// A ```json block is the same, on JSON's reader: a fence is a document of
// another kind inside this one, and a .json has these motions too.
//
// The fallbacks handed in below are, deliberately, the very commands text mode
// binds those keys to. So "markdown mode outside a fence" and "text mode" are
// the same key doing the same thing, and not two spellings of nearly that.
//
// The senses are Calva's, since that is what the VSCode keymap binds and it is
// the same hands here: option+l over the next form, option+j over the previous,
// option+k into the next list, option+i out of this one to the right.
export function sexpAware(motion, fallback) {
  return function (view) {
    const text = view.state.doc.toString();
    const pos = view.state.selection.main.head;
    const fence = formsFenceAt(text, pos);
    if (!fence) return fallback(view);
    const target = motion(text, pos, fence.from, fence.to, READERS[fence.reader]);
    view.dispatch({selection: {anchor: target, head: target}, scrollIntoView: true});
    return true;
  };
}

// The same for a ```clojure or ```json fence, which the ctrl pair now asks
// about first: inside one, the ends of the form the caret is in, exactly as in
// a .clj or a .json. A fence is a document of another kind inside this one, and
// the whole of what the library claims about Clojure and JSON in markdown is
// that each behaves there as it does in a file.
export function inFormsFence(codeward, proseward) {
  return function (text, pos) {
    const fence = formsFenceAt(text, pos);
    return fence ? codeward(text, pos, fence.from, fence.to, READERS[fence.reader])
                 : proseward(text, pos);
  };
}

// The ctrl pair, once markdown has a second language it understands inside a
// fence. Composed rather than wrapped: this returns a *pure* motion, still
// (text, pos) -> pos, so motion() and selectTo() put it on the keys exactly as
// they put the sentence motions there — and shift+ctrl+j goes on selecting as far
// as ctrl+j moves without a second decision being made anywhere.
//
// The fence's own bounds are handed on, so a line motion inside a block cannot
// step out onto the closing ``` — the same confinement the sexp motions have, and
// for the same reason: a chord that means "the neighbouring line" should not, at
// the edge, mean "leave the code".
export function inShellFence(shellward, proseward) {
  return function (text, pos) {
    const fence = shellFenceAt(text, pos);
    return fence ? shellward(text, pos, fence.from, fence.to) : proseward(text, pos);
  };
}

// **Built once, not once per table.** These need no `commands` namespace, so
// there is no reason for two builds of a mode to hold two closures that behave
// alike — and every reason not to: it is what lets text mode's ctrl+j and input
// mode's be the very same object, which is a claim a test can make by identity
// rather than by running both and comparing.
const lineBack = motion(lineStartOrPrevEnd);
const lineForward = motion(lineEndOrNextStart);
const selectLineBack = selectTo(lineStartOrPrevEnd);
const selectLineForward = selectTo(lineEndOrNextStart);

// Source mode's ctrl+j: one stage more than the text-mode pair above — the
// indent first, then the line start, then the end of the line above. Its
// forward partner is text mode's lineForward unchanged: the spec gives ctrl+l
// no indent stage, an end of line being an end of line in any language.
const sourceLineBack = motion(indentOrLineStartOrPrevEnd);
const selectSourceLineBack = selectTo(indentOrLineStartOrPrevEnd);

// A sexp motion, over the whole document rather than over a fence in one. The
// four take (text, pos, from, to) because in markdown they are confined to the
// block they were found in; a Clojure *file* is that block, so the bounds are
// the document and this is a pure (text, pos) -> pos like every other motion
// here — which is what lets motion() and selectTo() put it on the keys with no
// second mechanism.
//
// **Which reader, too**, since there are two: a .clj reads Clojure's syntax and
// a .json reads JSON's, and the walk over the forms is the same walk. So the
// twelve chords a file of forms gets are built by one function, once per
// reader, and clojure mode and json mode are that function's two answers — the
// same chords to the same motions, which cannot come to differ in anything but
// the characters.
function overTheFile(syntax) {
  const over = sexp => (text, pos) => sexp(text, pos, 0, text.length, syntax);
  return {
    // The option four. The senses stay Calva's, as they are in a fence.
    'KeyJ alt': motion(over(backwardSexp)),
    'KeyL alt': motion(over(forwardSexp)),
    'KeyI alt': motion(over(forwardUpSexp)),
    'KeyK alt': motion(over(forwardDownSexp)),

    // The ctrl pair: the two ends of the form the caret is in, just inside its
    // delimiters. It steps over whatever lies between — a nested list is
    // stepped over whole, exactly as it is by option+j — because what decides
    // the destination is the form the caret sits in and nothing smaller.
    'KeyJ ctrl': motion(over(formStart)),
    'KeyL ctrl': motion(over(formEnd)),
    'KeyJ ctrl+shift': selectTo(over(formStart)),
    'KeyL ctrl+shift': selectTo(over(formEnd)),

    // The leftward pair, one modifier up: ctrl+option+i out of this list to the
    // left, ctrl+option+k into the previous one at its right edge. Mirrors of
    // option+i and option+k, and the spec names them in exactly those words.
    // In markdown these two ask for the block first; here there is nothing to
    // ask.
    'KeyI alt+ctrl': motion(over(backwardUpSexp)),
    'KeyK alt+ctrl': motion(over(backwardDownSexp)),

    // option+delete: backward-kill-sexp, the same bounds and the same motion as
    // option+j, removed rather than walked.
    'Backspace alt': deleteTo(over(backwardSexp)),

    // ctrl+delete: from the caret to the beginning of the form it is in. The
    // kill that mirrors ctrl+j, as option+delete mirrors option+j — and the same
    // mirroring the other modes already have, where ctrl+j is the start of the
    // line and ctrl+delete deletes to it.
    'Backspace ctrl': deleteTo(over(formStart))
  };
}

const CLOJURE_FILE = overTheFile(clojureSyntax);
const JSON_FILE = overTheFile(jsonSyntax);

// Inside a shell-like fence the backward motion is *source mode's*, indent
// stage and all — a fence is a document of another kind inside this one, and
// the chord should mean there what it means in a file of that kind. When source
// mode's ctrl+j grew its indent stage, the fence had to grow it in the same
// commit or the claim would have quietly become false.
// Markdown's ctrl pair, which asks two questions before it is the block motion:
// am I in a ```clojure or ```json fence — then the ends of the form, as a .clj
// or a .json gives them — and am I in a shell-like one, then the ends of the
// line. Only outside both is
// it markdown's own block motion. The order is the specific before the general;
// the two fences cannot both be true of one caret.
const ctrlBack = inFormsFence(formStart, inShellFence(indentOrLineStartOrPrevEnd, sentenceStart));
const ctrlForward = inFormsFence(formEnd, inShellFence(lineEndOrNextStart, sentenceEnd));

const proseBack = motion(ctrlBack);
const proseForward = motion(ctrlForward);
const selectProseBack = selectTo(ctrlBack);
const selectProseForward = selectTo(ctrlForward);

// A chord that is bound to nothing happening. Not the same as an unbound chord:
// install() preventDefaults and stops anything it finds in the table, so this
// *swallows* the key, and the app underneath never sees it.
//
// It is what the four vertical keys become in input mode. Leaving them out
// instead would let each app give cmd+k a second meaning of its own in a field
// where the scheme has none — and then the same finger does two different things
// depending on which box the caret is in, which is the one thing a keyboard
// layout exists to prevent.
//
// The cost is real and worth naming: tracker binds option+i globally to "go to
// Issues", and in a field this swallows it. If that trade ever wants reversing,
// it is this list and nothing else.
export function swallow() { return true; }

const DEAD_IN_ONE_LINE = [
  'KeyI meta', 'KeyK meta',               // cursor up / down
  'KeyI meta+shift', 'KeyK meta+shift',   // ...selecting
  'KeyI alt', 'KeyK alt',                 // in prose these are up / down too
  'KeyI alt+shift', 'KeyK alt+shift'
];

// The chords that mean exactly the same thing whether the document is one line or
// a thousand, prose or a shell script. Every table here is built on this, so a
// change to one of these cannot land in one mode and miss the others.
function sharedBindings(commands) {
  return {
    // Motion, and the same selecting
    'KeyJ meta': commands.cursorCharLeft,
    'KeyL meta': commands.cursorCharRight,
    'KeyJ meta+shift': commands.selectCharLeft,
    'KeyL meta+shift': commands.selectCharRight,
    'KeyJ alt+shift': commands.selectGroupLeft,
    'KeyL alt+shift': commands.selectGroupRight,

    // Deleting. deleteLine survives into input mode, where it empties the field —
    // which is a chord for "clear this box" and reads as one.
    //
    // option+delete is the mirror of option+= and was unbound for a long while,
    // which worked only because the browser does very nearly this on its own.
    // The spec names it — "delete last token" in a source file, "delete last
    // SEXP" in a Lisp one — so it is the scheme's chord and belongs in the
    // table. Where the document has forms in it, the modes below override it
    // with one; a group backwards is what "the thing to the left" means when
    // there are no forms.
    'Backspace alt': commands.deleteGroupBackward,
    'Equal alt': commands.deleteGroupForward,
    'Equal meta': commands.deleteCharForward,
    'Backspace ctrl': commands.deleteToLineStart,
    'Equal ctrl': commands.deleteToLineEnd,
    'Equal ctrl+meta': commands.deleteLine,

    // Everything else
    'KeyA alt': commands.selectAll,
    'Backquote alt': commands.undo,
    'Backquote shift': commands.redo,
    'KeyC alt': copySelection,
    'KeyV alt': pasteAtSelection,
    'KeyX alt': cutSelection
  };
}

// Everything that exists because there is a second line: somewhere to move up
// and down to, lines to open and move and indent, pages to turn, a viewport
// taller than the caret.
//
// This is the whole of text mode, and the base of markdown's and shell's. The
// motions here are the *plain* ones — word left and right, line up and down,
// the ends of the line — because those are what a document with no blocks and
// no fenced code in it can offer. A mode that has more says so by overriding,
// and what it overrides is exactly the list of things markdown knows and a text
// file does not.
function multiLineBindings(commands) {
  return Object.assign(sharedBindings(commands), {
    // Up and down, and the same selecting.
    'KeyI meta': commands.cursorLineUp,
    'KeyK meta': commands.cursorLineDown,
    'KeyI meta+shift': commands.selectLineUp,
    'KeyK meta+shift': commands.selectLineDown,
    'KeyI alt+shift': commands.selectLineUp,
    'KeyK alt+shift': commands.selectLineDown,

    // The option four, plainly: by word sideways, by line up and down. In
    // markdown these are the fence-aware ones and these commands are what they
    // fall back to.
    'KeyJ alt': commands.cursorGroupLeft,
    'KeyL alt': commands.cursorGroupRight,
    'KeyI alt': commands.cursorLineUp,
    'KeyK alt': commands.cursorLineDown,

    // The ends of the line. Markdown makes these the ends of the *block*; a
    // file with no blocks in it has the line, which is the same idea at the only
    // scale it has.
    //
    // Not CodeMirror's cursorLineStart/End, because those stop dead once the
    // caret is already at the end they name. These step on to the neighbouring
    // line instead — ctrl+j from the start of a line to the end of the one above,
    // ctrl+l from the end of a line to the start of the one below — so the second
    // press does something and the pair walks the file. See motions.js.
    'KeyJ ctrl': lineBack,
    'KeyL ctrl': lineForward,
    'KeyJ ctrl+shift': selectLineBack,
    'KeyL ctrl+shift': selectLineForward,

    // Lines
    'Enter shift': newLineBelow,
    'Enter meta': newLineAbove,
    'KeyI ctrl+meta': commands.moveLineUp,
    'KeyK ctrl+meta': commands.moveLineDown,
    'KeyL ctrl+meta': commands.indentMore,
    'KeyJ ctrl+meta': commands.indentLess,

    // Pages and the whole document
    'KeyP alt+meta': commands.cursorPageUp,
    'Semicolon alt+meta': commands.cursorPageDown,
    'KeyP alt+ctrl+meta': commands.cursorDocStart,
    'Semicolon alt+ctrl+meta': commands.cursorDocEnd,

    // The view, with and without the caret. See the NOTE in custom-commands.js
    // about the up key scrolling down.
    'KeyI alt+meta+shift': scrollDown,
    'KeyK alt+meta+shift': scrollUp,
    'KeyI alt+meta': cursorViewportUp(commands),
    'KeyK alt+meta': cursorViewportDown(commands),
    'Semicolon meta': centerCaret,
    'Semicolon ctrl+meta': centerLine
  });
}

// A markdown document: blocks to move between, fences to move inside. The
// layout every consumer had before there were modes, and still the default.
//
// Eight chords, and no ninth. Everything else — up and down, the line
// operations, paging, the clipboard — is inherited and therefore identical, by
// identity, to what a text file gets.
export function markdownBindings(commands) {
  return Object.assign(multiLineBindings(commands), {
    // The option four move by form inside a ```clojure or ```json block, on
    // that language's reader, and by word or line everywhere else, which is
    // exactly what they do in text mode.
    'KeyJ alt': sexpAware(backwardSexp, commands.cursorGroupLeft),
    'KeyL alt': sexpAware(forwardSexp, commands.cursorGroupRight),
    'KeyI alt': sexpAware(forwardUpSexp, commands.cursorLineUp),
    'KeyK alt': sexpAware(forwardDownSexp, commands.cursorLineDown),

    // ctrl+j and ctrl+l move by markdown "sentence" — the line when the one
    // above ended in two spaces, and the block otherwise — and their shifted
    // pair selects as far as they move.
    //
    // Except inside a fence, where they are what a file of that kind gives
    // them: the ends of the *form* in a ```clojure or ```json block, the ends
    // of the *line* in a shell-like one, all confined to the block. Same idea as the
    // option four one line up. The block motions are actively wrong in a code
    // block — no blank lines in it, so "the end of this block" is the far side
    // of the whole listing.
    'KeyJ ctrl': proseBack,
    'KeyL ctrl': proseForward,
    'KeyJ ctrl+shift': selectProseBack,
    'KeyL ctrl+shift': selectProseForward,

    // The leftward structural pair, which exists only where there is structure.
    // Inside a ```clojure or ```json fence they are the motions; outside one there is
    // nothing for them to mean, so they are *swallowed* rather than left
    // unbound — the same choice DEAD_IN_ONE_LINE makes, and for the same
    // reason: a chord the scheme has given a meaning must not pick up a second
    // one from whichever app the caret happens to be in.
    'KeyI alt+ctrl': sexpAware(backwardUpSexp, swallow),
    'KeyK alt+ctrl': sexpAware(backwardDownSexp, swallow),

    // Kill the form to the left, inside a fence; the group to the left outside
    // one, which is what sharedBindings already binds and what the key did
    // before it was in any table at all.
    'Backspace alt': sexpAwareDelete(backwardSexp, commands.deleteGroupBackward),

    // And inside a fence, ctrl+delete kills back to the start of the form —
    // what this mode's ctrl+j now does in there. Outside one it is the start of
    // the line, as everywhere else.
    'Backspace ctrl': sexpAwareDelete(formStart, commands.deleteToLineStart)
  });
}

// The name this layout had when it was the only document layout there was. Kept
// as the same function and not as a copy, so nothing can drift between them.
export const documentBindings = markdownBindings;

// A text file: lines, and nothing above a line.
//
// It is the multi-line base with nothing added, and that is the point rather
// than a gap. `.txt` is the shape everything else here is described as a
// difference from: markdown is this plus blocks and fences, a shell script is
// this exactly, a one-line field is this minus the second line.
export function textBindings(commands) {
  return multiLineBindings(commands);
}

// A source-code file that is not Lisp — a shell script, a .py, a Makefile, a
// .yaml, a .js. A text file, except where being code makes a difference, and
// the differences land here one spec section at a time:
//
//   ctrl+j            **the indent stage.** To the start of the indentation
//                     first — in code that is where the line begins as far as
//                     reading it is concerned — then the line start, then the
//                     end of the line above. On an unindented line the first
//                     two stages coincide, and the chord is text mode's
//                     exactly. ctrl+l is *inherited*, not overridden: the spec
//                     gives it no indent stage, an end of line being an end of
//                     line in any language.
//
// Still to come from the spec's *Source file editing* section: token motion
// that knows what a token is in code, a camelCase-aware pair one modifier up,
// and the token deletes.
//
// The same difference reaches a shell-like fence in a markdown document
// through proseBack above, so a ```sh block and a .sh file cannot drift apart.
export function sourceBindings(commands) {
  return Object.assign(multiLineBindings(commands), {
    'KeyJ ctrl': sourceLineBack,
    'KeyJ ctrl+shift': selectSourceLineBack
  });
}

// The old name, as the same function and not as a copy — see SHELL above.
export const shellBindings = sourceBindings;

// A Clojure source file — .clj, .cljs, .cljc, .edn.
//
// **The same eight chords markdown overrides, and no ninth**, which is the whole
// claim: markdown mode already knows how to edit Clojure, it just has to find a
// ```clojure fence first. Here the file is the fence. So this is not a fifth
// behaviour to learn — it is the behaviour the same hands already get inside a
// code block in a README, on a document that happens to be all code.
//
// Both halves of that follow from one fact, that the document *is* Clojure:
//
//   the option four   move by form, over the whole file. In markdown these are
//                     sexpAware(): ask for the fence, move by form inside it,
//                     fall back to word and line outside. There is no outside
//                     here, so the ask is gone and the bounds are 0..length.
//                     The senses stay Calva's, as they are in a fence.
//   the ctrl pair     the two ends of the form the caret is *in*, just inside
//                     its delimiters — (a b c|) to (|a b c) — the innermost
//                     list winning, and staying put when pressed again rather
//                     than jumping out of the form. It steps over whatever lies
//                     between, a nested list included, because what decides the
//                     destination is the form the caret sits in and nothing
//                     smaller. See formStart and formEnd in sexp.js.
//
// The line motions are still there, one modifier away: cmd+j and cmd+l are the
// character, alt+j and alt+l are now the form. What is *not* here is a line
// motion on the ctrl pair, which is the one thing a reader who was in a .txt a
// moment ago has to be told.
//
// **The ctrl pair used to be the block motion**, markdown's own, on the
// argument that a Clojure file is written with a blank line between top-level
// forms. It is not the same thing and the difference showed: from inside a
// nested form the block motion left the form entirely, because it cannot see a
// list at all. The spec asks for the form, so the form it is.
export function clojureBindings(commands) {
  return Object.assign(multiLineBindings(commands), CLOJURE_FILE);
}

// A JSON file — .json, .jsonc.
//
// **Clojure mode, on JSON's reader, and nothing else** — the same twelve chords
// to the same motions, so the hands that know a .clj know this already. What
// makes that honest rather than approximate is how JSON is read (jsonSyntax in
// sexp.js): a value is a form, an object or an array is a list, and the colon
// is whitespace beside the comma. A key and its value are then two forms side
// by side, which is exactly what they are in a Clojure map —
//
//   option+delete  "abc": "def"|         →  "abc": |
//   option+l       {|"abc": "def"}       →  {"abc"|: "def"}
//   ctrl+j         {"a": [1, 2|]}        →  {"a": [|1, 2]}
//
// — so option+l walks key, value, key, value, and a kill takes a value and
// leaves its key and colon standing for the next one to be typed.
//
// Separate from clojure mode rather than a flag on it, because the file is not
// Clojure: a `;` is not a comment in JSON, a `#` is not a prefix, and a paren
// delimits nothing.
export function jsonBindings(commands) {
  return Object.assign(multiLineBindings(commands), JSON_FILE);
}

// One line: a title, a search box, a URL. Pair it with singleLine() from
// single-line.js, which is what stops the document becoming two lines behind the
// layout's back.
//
// Built on sharedBindings and not on the multi-line base, because what it wants
// is nearly none of that: everything to do with a second line is simply absent —
// no new line above or below, no moving or indenting one, no paging, no
// scrolling or centring a viewport that is one line tall. Written as an
// inheritance it would be a list of sixteen deletions, which is a worse way of
// saying the same thing and a much easier one to get wrong.
//
// Three differences from the multi-line modes, and no fourth:
//
//   the option pair    word motion, plainly — as in text mode, and for the same
//                      reason markdown mode would not: there is no fenced block
//                      in a one-line field, so asking is a document scan on
//                      every keypress to answer no.
//   ctrl+j / ctrl+l    line start and end. The same commands text mode binds —
//                      the same objects, not a second spelling — and in one line
//                      the step-to-the-neighbouring-line half of them can never
//                      fire, because there is no neighbouring line. In one line
//                      the markdown sentence motions *already* degenerate to
//                      exactly this destination, so this is not a second meaning
//                      for the chord; it is the same one reached without dragging
//                      markdown's definition of a block into a field that has
//                      none.
//   the vertical keys  swallowed. See DEAD_IN_ONE_LINE.
export function inputBindings(commands) {
  const table = Object.assign(sharedBindings(commands), {
    'KeyJ alt': commands.cursorGroupLeft,
    'KeyL alt': commands.cursorGroupRight,
    'KeyJ ctrl': lineBack,
    'KeyL ctrl': lineForward,
    'KeyJ ctrl+shift': selectLineBack,
    'KeyL ctrl+shift': selectLineForward
  });
  for (const dead of DEAD_IN_ONE_LINE) table[dead] = swallow;
  return table;
}

// Every mode, and the table each one builds. The two old names are in here too —
// 'document' for 'markdown', 'shell' for 'source' — resolving to the same
// functions their current names do.
const LAYOUTS = {
  [MARKDOWN]: markdownBindings,
  [TEXT]: textBindings,
  [SOURCE]: sourceBindings,
  [SHELL]: sourceBindings,
  [CLOJURE]: clojureBindings,
  [JSON_MODE]: jsonBindings,
  [INPUT]: inputBindings,
  [DOCUMENT]: markdownBindings
};

// The layout, as chord string -> CodeMirror command. Modifiers are spelled in the
// order chord() produces them — alt, ctrl, meta, shift — and a key in any other
// order can never fire, which is why a test checks it.
//
//   bindings(commands)                       the markdown layout
//   bindings(commands, {mode: 'text'})       a text file
//   bindings(commands, {mode: 'source'})     a source file — .sh, .py, a Makefile
//   bindings(commands, {mode: 'clojure'})    a Clojure source file
//   bindings(commands, {mode: 'json'})       a JSON file
//   bindings(commands, {mode: 'input'})      a one-line field
//
// **Markdown is the default, and that is not only history.** It is what every
// caller that passes no mode has always got, so modes arriving cannot change any
// of them; and it is the most forgiving of the four to be wrong about, since it
// is the only one that adds behaviour rather than removing it — markdown in a
// text file costs a fence scan that finds nothing, where text in a markdown file
// silently loses the block motions.
export function bindings(commands, options) {
  const mode = (options && options.mode) || MARKDOWN;
  const layout = LAYOUTS[mode];
  // Loudly. A typo'd mode that quietly fell back to the markdown layout would
  // put block motions and fence scanning in a search box and look almost right.
  if (!layout) {
    throw new Error(`unknown editor mode ${JSON.stringify(mode)} — expected one of ` +
                    [MARKDOWN, TEXT, SOURCE, CLOJURE, JSON_MODE, INPUT]
                      .map(m => JSON.stringify(m)).join(', '));
  }
  return layout(commands);
}

// Capture phase on the editor element, rather than a CodeMirror keymap
// extension, so these win before CodeMirror's own keymaps see the event —
// which is also how tracker's codemirror.cljs has always done it.
//
//   install(view, commands)                    the markdown layout
//   install(view, commands, {mode: 'text'})    ...or any other mode
//   install(view, commands, {table})           a caller's own table
//
// Note what install does *not* touch: Enter, Escape, Tab, the arrows. They are in
// neither table, so they are not preventDefaulted and not stopped, and they reach
// whatever the app has on the field — which for tracker's search boxes is "add
// this item", "clear the filter", and walking the result list. A single-line
// editor that swallowed Enter would be useless in a form.
//
// Returns a function that takes the bindings back off again.
export function install(view, commands, options) {
  options = options || {};
  const table = options.table || bindings(commands, options);
  const onKeydown = function (e) {
    const command = table[chord(e)];
    if (!command) return;
    e.preventDefault();
    e.stopPropagation();
    command(view);
  };
  view.dom.addEventListener('keydown', onKeydown, true);
  return function uninstall() {
    view.dom.removeEventListener('keydown', onKeydown, true);
  };
}
