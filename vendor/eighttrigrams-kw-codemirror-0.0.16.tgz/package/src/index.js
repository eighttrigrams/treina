// The package surface.
//
//   install(view, commands, opts)   put a layout on a mounted EditorView
//   uninstall = install(...)        take it back off
//   bindings(commands, opts)        the layout itself, to read or extend
//   MARKDOWN / TEXT / SOURCE / CLOJURE / JSON_MODE / INPUT
//                                  the modes, spelled rather than typed —
//                                  JSON_MODE because an export named JSON
//                                  would shadow the global
//   modeFor(path)                  which mode a file gets, by its name — the
//                                  file-types spec as code, or null for a file
//                                  the scheme has no layout for
//   chord(event)                   a keydown event as a chord string, e.g. "KeyJ alt"
//   motion(fn)                     a pure (text, pos) -> pos as a CodeMirror command
//   selectTo(fn)                   the same, but selecting rather than moving
//   deleteTo(fn)                   the same, but removing what lies between
//   sentenceStart/sentenceEnd      the markdown "sentence" motions themselves
//   lineStartOrPrevEnd/...NextStart  the line motions text mode uses
//   indentOrLineStartOrPrevEnd     source mode's ctrl+j — the indent, then the
//                                  line start, then the end of the line above
//   singleLine(cm)                 extensions making a document that stays one line
//   oneLine(text)                  that same flattening, for a doc before it exists
//   fromTextarea(ta, cm)           replace a form's <textarea> with an editor on it
//   fromTextareas(root, cm)        the same for every marked textarea under root
//
// Six modes, because a title field is not a markdown document and neither is a
// shell script or a namespace of Clojure. `install(view, commands)` is the
// markdown layout, as it always was — every caller that passes no mode is
// untouched by modes existing — and `{mode: 'text'}`, `{mode: 'source'}`,
// `{mode: 'clojure'}`, `{mode: 'json'}` and `{mode: 'input'}` are the other
// five. Pair the last
// with `singleLine(cm)`: the layout says what the keys do, singleLine says what
// the document may be, and a field wants both.
//
// `DOCUMENT` is 'markdown' under the name it had when it was the only one, and
// `SHELL` is 'source' under its first, narrower name — both kept working because
// they are exported and blog re-exports the whole surface on `window.IJKL`.
//
// The pure functions are exported alongside the bindings on purpose: they are
// the part worth testing — and they are where structured LISP editing came
// from: sexp.js was written for the four motions inside a ```clojure fence, and
// 'clojure' mode is those same four with the whole file for bounds.

export {install, bindings,
        markdownBindings, textBindings, sourceBindings, shellBindings,
        clojureBindings, jsonBindings, inputBindings, documentBindings,
        chord, motion, selectTo, deleteTo, sexpAware, sexpAwareDelete,
        inShellFence, swallow,
        MARKDOWN, TEXT, SOURCE, SHELL, CLOJURE, JSON_MODE, INPUT, DOCUMENT} from './bindings.js';
export {modeFor} from './file-types.js';
export {singleLine, noNewlines, oneLine} from './single-line.js';
export {fenceAt, clojureFenceAt, jsonFenceAt, formsFenceAt, shellFenceAt} from './fences.js';
export {forwardSexp, backwardSexp, forwardDownSexp, forwardUpSexp,
        backwardUpSexp, backwardDownSexp, clojureSyntax, jsonSyntax} from './sexp.js';
export {sentenceStart, sentenceEnd,
        lineStartOrPrevEnd, lineEndOrNextStart,
        indentOrLineStartOrPrevEnd} from './motions.js';
export {fromTextarea, fromTextareas} from './textarea.js';
