// Which mode is this file? — specs/file-types.md as code, written down once,
// here, instead of once per app.
//
// Every consumer used to keep a list like this of its own (the coordinator's
// kinds.cljc was the fullest), and two lists drift: an extension added to one
// panel and not the other is the same file opening with two different keyboards.
// An app that mounts an editor on a file asks the library that owns the layouts
// which one the file wants.
//
//   modeFor('notes.md')          'markdown'
//   modeFor('src/core.clj')      'clojure'
//   modeFor('deploy.sh')         'source'
//   modeFor('docs/photo.png')    null — no layout; do not mount this scheme
//
// **By name, never by content.** The decision is made before anything is read —
// a file tree decides how to open a file it has not fetched — so a script called
// `run` with a `#!/bin/sh` first line is not source as far as this is concerned.
//
// **null rather than a default, for a file the scheme has no layout for.** Which
// mode to fall back to is the app's decision — a notes box wants markdown, a
// file pane wants to not open the file at all — and a mapping that answered
// 'markdown' for a .png would be making that decision for it.
//
// **And 'input' is not in here**, deliberately: a one-line field is a shape of
// *widget*, not a kind of file, and no path answers to it.

import {MARKDOWN, TEXT, SOURCE, CLOJURE} from './bindings.js';

// The extensions, each to its mode. `env` is in here as an extension rather
// than `.env` as a name, so `production.env` is the same kind of file `.env`
// is — which it is.
const EXTENSIONS = {
  md: MARKDOWN, markdown: MARKDOWN,
  txt: TEXT, text: TEXT,
  clj: CLOJURE, cljs: CLOJURE, cljc: CLOJURE, edn: CLOJURE,
  sh: SOURCE, bash: SOURCE, zsh: SOURCE, conf: SOURCE, env: SOURCE,
  py: SOURCE, toml: SOURCE, yaml: SOURCE, yml: SOURCE, js: SOURCE
};

// Files known by their whole name, having no extension to go by. The two ignore
// files are named one at a time where the rc files get a wildcard, because here
// the wildcard would be the wrong shape: `.gitignore` and `.dockerignore` are
// lists of patterns with `#` comments, and so are half a dozen others, but the
// spec names two and adding a third is one word here.
const NAMES = {
  makefile: SOURCE,
  '.gitignore': SOURCE,
  '.dockerignore': SOURCE
};

// The dotenv family is a prefix rather than a name: `.env` itself answers to
// the `env` extension above, and `.env.example`, `.env.local`, `.env.sanlam`
// are the same kind of file under the convention's own naming — the variant
// goes *after* the extension, which is why no extension rule can catch them.
// A file merely mentioning env (`env.example`, `preview.envx`) is not one.
function dotEnv(name) {
  return name.startsWith('.env.');
}

// **The dot-rc files are a wildcard, and that is the spec's word.** `.envrc` is
// literally a shell script that direnv sources, `.zshrc` and `.bashrc` are the
// shells' own; the pattern is any dotfile whose name ends in `rc`, so the ones
// nobody has thought of yet are in too. It lets one file through that is not
// source-like at all — `.babelrc` is JSON — and that is the trade the spec asks
// for: a rule you can say in four characters, against a list that would need
// adding to forever.
function dotRc(name) {
  return name.startsWith('.') && name.endsWith('rc');
}

// The mode whose layout this path gets — 'markdown', 'text', 'source' or
// 'clojure' — or null for a file the scheme has no layout for, which is nearly
// everything and deliberately so.
//
// The last path segment decides, lower-cased: a MAKEFILE is a Makefile, and a
// directory called `src` on the way to something else is not an rc file. A
// `.template` suffix comes off first and the rest is treated as what remains —
// the spec's own rule, so `app.conf.template` is a .conf with the values still
// to fill in.
export function modeFor(path) {
  let name = String(path == null ? '' : path);
  name = name.slice(name.lastIndexOf('/') + 1).toLowerCase();
  while (name.endsWith('.template')) name = name.slice(0, -'.template'.length);
  if (Object.hasOwn(NAMES, name)) return NAMES[name];
  if (dotRc(name) || dotEnv(name)) return SOURCE;
  const dot = name.lastIndexOf('.');
  const ext = dot === -1 ? '' : name.slice(dot + 1);
  return Object.hasOwn(EXTENSIONS, ext) ? EXTENSIONS[ext] : null;
}
