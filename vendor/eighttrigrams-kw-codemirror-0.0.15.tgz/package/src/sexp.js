// Structural movement over Clojure forms — and over JSON values, which are
// forms to a reader that files its characters differently (see jsonSyntax).
// Pure functions of (text, pos, from, to[, syntax]) -> pos, where from/to are
// the bounds movement may not leave — in practice the body of a ```clojure
// fence, from fences.js, or a whole file.
//
// The names and senses are Calva's, because Daniel's VSCode keybindings bind
// Calva's paredit and it is the same hands using both. Calva's own code is not
// what is here: its paredit works on an EditableDocument through a LispTokenCursor
// and a lexer, which is a great deal of machinery to transplant for four motions,
// and it knows nothing about being confined to part of a markdown document.
//
// What replaces it is one pass that says, for every character, whether it is
// code, inside a string, inside a comment, or part of a character literal. Every
// motion below then only has to look at code characters. That is what keeps the
// awkward cases honest — a ; inside a string is not a comment, a paren inside a
// string is not a delimiter, \( is not a delimiter either — without a tokenizer.
//
// Known limits, all of which degrade to "moves like an atom" rather than to
// anything destructive: #_ marks the form after it as discarded and this treats
// it as an ordinary prefix, so a discarded form is still a form to move over; and
// metadata like ^{:a 1} is two forms to this, not one.

const CODE = 0, STRING = 1, COMMENT = 2, CHARLIT = 3;

// **Two readers, one set of motions.** What a form is differs between Clojure
// and JSON only in which characters are which — the walking over them is the
// same walk — so the motions below take the reader as a last argument, and a
// caller that names none gets Clojure's, which is what every caller had before
// there was a second.
//
//   ws        what separates forms. Comma is whitespace in Clojure.
//   open      the opening delimiters, and close their partners.
//   prefix    reader syntax that belongs to the form after it.
//   comment   whether a comment starts at text[i]. `blockComment` says
//             whether a `/*` one runs to `*/` rather than to the end of the line.
//   charLits  whether a backslash outside a string starts a literal — \x,
//             \newline — or is just a character.
export const clojureSyntax = {
  ws: ' \t\r\n\f,',
  open: '([{',
  close: ')]}',
  prefix: "'`~@^#",
  comment: (text, i) => text[i] === ';',
  charLits: true
};

// JSON as the same reader with its own characters. **The colon is whitespace**,
// beside the comma, and that is the whole trick: `"abc": "def"` is then two
// forms side by side, which is exactly what `{"abc" "def"}` is in a Clojure map
// — so option+l steps from key to value, and option+delete after `"def"` takes
// the value and leaves `"abc":` standing. Only square and curly brackets
// delimit; a paren in JSON is nothing, and outside a string it cannot appear.
//
// Comments are JSONC's, `//` and `/* */`. Strict JSON has none, and in strict
// JSON a slash can only appear inside a string — so reading them costs a valid
// file nothing, and it is what a VSCode settings.json, a tsconfig.json or a
// .jsonc needs to be read at all rather than read wrongly.
export const jsonSyntax = {
  ws: ' \t\r\n\f,:',
  open: '[{',
  close: ']}',
  prefix: '',
  comment: (text, i) => text[i] === '/' && (text[i + 1] === '/' || text[i + 1] === '*'),
  blockComment: true,
  charLits: false
};

// One pass over the bounds, classifying every character. Cheap enough to do per
// keystroke: a fenced block is small, and correctness here is what the motions
// stand on.
function classify(text, from, to, syntax) {
  const mask = new Uint8Array(Math.max(0, to - from));
  let i = from;
  while (i < to) {
    const c = text[i];
    const opener = syntax.comment(text, i);
    if (opener && syntax.blockComment && text[i + 1] === '*') {
      let j = i + 2;                            // past the opener, so /*/ is not closed
      while (j < to && !(text[j] === '*' && text[j + 1] === '/')) j++;
      const end = Math.min(to, j + 2);          // an unclosed one runs to the bounds
      while (i < end) mask[i++ - from] = COMMENT;
      continue;
    }
    if (opener) {
      while (i < to && text[i] !== '\n') mask[i++ - from] = COMMENT;
      continue;
    }
    if (c === '"') {
      mask[i++ - from] = STRING;
      while (i < to) {
        if (text[i] === '\\') {                 // \" does not end the string
          mask[i++ - from] = STRING;
          if (i < to) mask[i++ - from] = STRING;
          continue;
        }
        const closing = text[i] === '"';
        mask[i++ - from] = STRING;
        if (closing) break;
      }
      continue;
    }
    if (c === '\\' && syntax.charLits) {       // \x, \newline, \space
      mask[i++ - from] = CHARLIT;
      if (i < to) mask[i++ - from] = CHARLIT;
      while (i < to && /[A-Za-z0-9-]/.test(text[i])) mask[i++ - from] = CHARLIT;
      continue;
    }
    mask[i++ - from] = CODE;
  }
  return mask;
}

// A scanner bound to one set of bounds, so the motions below read as prose.
function scanner(text, from, to, syntax) {
  const {ws: WS, open: OPEN, close: CLOSE, prefix: PREFIX} = syntax;
  const mask = classify(text, from, to, syntax);
  const kind = i => mask[i - from];
  const code = i => i >= from && i < to && mask[i - from] === CODE;
  const isWs = i => code(i) && WS.includes(text[i]);
  const isOpen = i => code(i) && OPEN.includes(text[i]);
  const isClose = i => code(i) && CLOSE.includes(text[i]);
  const isPrefix = i => code(i) && PREFIX.includes(text[i]);

  // Whitespace and comments are not forms; movement passes over them.
  const skipForward = i => {
    while (i < to && (kind(i) === COMMENT || isWs(i))) i++;
    return i;
  };
  const skipBackward = i => {
    while (i > from && (kind(i - 1) === COMMENT || isWs(i - 1))) i--;
    return i;
  };

  // text[i] is an opening delimiter: one past its match, or `to` if unbalanced.
  const matchForward = i => {
    let depth = 0;
    while (i < to) {
      if (isOpen(i)) depth++;
      else if (isClose(i) && --depth === 0) return i + 1;
      i++;
    }
    return to;
  };

  // text[i-1] is a closing delimiter: the index of its match, or `from`.
  const matchBackward = i => {
    let depth = 0;
    let j = i - 1;
    while (j >= from) {
      if (isClose(j)) depth++;
      else if (isOpen(j) && --depth === 0) return j;
      j--;
    }
    return from;
  };

  // One past the atom starting at i. A string or a character literal is an atom
  // whole, whatever it has inside it. An atom ends at a comment without asking
  // which reader's comment it is: a comment character is never code.
  const atomForward = i => {
    const k = kind(i);
    if (k === STRING || k === CHARLIT) {
      while (i < to && kind(i) === k) i++;
      return i;
    }
    while (i < to && code(i) && !WS.includes(text[i])
           && !OPEN.includes(text[i]) && !CLOSE.includes(text[i])) i++;
    return i;
  };

  // The start of the atom ending at i.
  const atomBackward = i => {
    const k = kind(i - 1);
    if (k === STRING || k === CHARLIT) {
      let j = i - 1;
      while (j > from && kind(j - 1) === k) j--;
      return j;
    }
    let j = i;
    while (j > from && code(j - 1) && !WS.includes(text[j - 1])
           && !OPEN.includes(text[j - 1]) && !CLOSE.includes(text[j - 1])) j--;
    return j;
  };

  return {code, isOpen, isClose, isPrefix, skipForward, skipBackward,
          matchForward, matchBackward, atomForward, atomBackward};
}

function bounded(pos, from, to) {
  if (!(pos > from)) return from;
  return pos > to ? to : pos;
}

// alt+l — over the next form. Stops at the end of the list it is in rather than
// climbing out of it; that is forwardUpSexp's job.
export function forwardSexp(text, pos, from, to, syntax = clojureSyntax) {
  const at = bounded(pos, from, to);
  const s = scanner(text, from, to, syntax);
  let i = s.skipForward(at);
  if (i >= to || s.isClose(i)) return pos;
  while (i < to && s.isPrefix(i)) i++;          // the prefix goes with its form
  if (i >= to) return i;
  return s.isOpen(i) ? s.matchForward(i) : s.atomForward(i);
}

// alt+j — over the previous form, and likewise stops at the start of its list.
export function backwardSexp(text, pos, from, to, syntax = clojureSyntax) {
  const at = bounded(pos, from, to);
  const s = scanner(text, from, to, syntax);
  const i = s.skipBackward(at);
  if (i <= from || s.isOpen(i - 1)) return pos;
  let start = s.isClose(i - 1) ? s.matchBackward(i) : s.atomBackward(i);
  while (start > from && s.isPrefix(start - 1)) start--;
  return start;
}

// alt+k — into the next list. A closing delimiter first means there is no list
// left in this one, and it stays rather than climbing out to find one elsewhere.
export function forwardDownSexp(text, pos, from, to, syntax = clojureSyntax) {
  const at = bounded(pos, from, to);
  const s = scanner(text, from, to, syntax);
  for (let i = at; i < to; i++) {
    if (s.isOpen(i)) return i + 1;
    if (s.isClose(i)) return pos;
  }
  return pos;
}

// alt+i — out of this list, to the right of it. Lists met on the way are stepped
// over, not entered.
export function forwardUpSexp(text, pos, from, to, syntax = clojureSyntax) {
  const at = bounded(pos, from, to);
  const s = scanner(text, from, to, syntax);
  let i = at;
  while (i < to) {
    if (s.isOpen(i)) { i = s.matchForward(i); continue; }
    if (s.isClose(i)) return i + 1;
    i++;
  }
  return pos;
}

// Out of this list, to the left of it.
export function backwardUpSexp(text, pos, from, to, syntax = clojureSyntax) {
  const at = bounded(pos, from, to);
  const s = scanner(text, from, to, syntax);
  let j = at;
  while (j > from) {
    if (s.isClose(j - 1)) { j = s.matchBackward(j); continue; }
    if (s.isOpen(j - 1)) return j - 1;
    j--;
  }
  return pos;
}

// Into the previous list, at its right edge — the mirror of alt+k.
export function backwardDownSexp(text, pos, from, to, syntax = clojureSyntax) {
  const at = bounded(pos, from, to);
  const s = scanner(text, from, to, syntax);
  for (let j = at; j > from; j--) {
    if (s.isClose(j - 1)) return j - 1;
    if (s.isOpen(j - 1)) return pos;
  }
  return pos;
}

// --- the two ends of the form you are standing in ----------------------------
//
// ctrl+j and ctrl+l in a Clojure document: the beginning and the end of the
// *enclosing* list, meaning just inside its delimiters —
//
//   (a b c| )            ->  (|a b c )
//   (comment (a b c|))   ->  (comment (|a b c))
//
// The innermost list wins, which is the one the caret is actually in. **Pressed
// again it stays**, which the spec says in as many words: "if already at the
// beginning of the SEXP, stay there (don't jump out of it)". So this pair is
// the one place in the scheme where a second press is deliberately a no-op —
// everywhere else the rule is that pressing again gets you somewhere further.
// The reason is that the form you are in is a *place*, not a step: climbing out
// of it on the second press would take the caret somewhere you never asked to
// be, and the way out of a form is the chord for going out of a form
// (ctrl+option+i).
//
// **Not the block motion.** In a file laid out with a blank line between
// top-level forms the two agree about where a top-level form starts, and
// nowhere else: the block motion cannot see a list at all, so from inside a
// nested form it left the form entirely. The block motion is markdown's, and a
// .clj is not a markdown document that happens to be code.

export function formStart(text, pos, from, to, syntax = clojureSyntax) {
  const at = bounded(pos, from, to);
  const open = backwardUpSexp(text, at, from, to, syntax);
  if (open === at) return pos;                  // nothing encloses the caret
  return open + 1 < at ? open + 1 : pos;        // just inside it, or stay
}

export function formEnd(text, pos, from, to, syntax = clojureSyntax) {
  const at = bounded(pos, from, to);
  const close = forwardUpSexp(text, at, from, to, syntax);
  if (close === at) return pos;
  return close - 1 > at ? close - 1 : pos;
}
